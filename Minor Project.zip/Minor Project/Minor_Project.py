import re
import nltk
from nltk.corpus import stopwords
from sklearn.datasets import load_files
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Download stopwords
nltk.download('stopwords')

# Load dataset (e.g., from txt_sentoken with 'pos' and 'neg' folders)
reviews = load_files("txt_sentoken")  # Make sure this folder exists with 'pos' and 'neg' subfolders
X, y = reviews.data, reviews.target
print(f"Loaded {len(reviews.data)} documents.")


# Text preprocessing function
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'<[^>]+>', '', text)  # Remove HTML tags
    text = re.sub(r'[^a-z\s]', '', text)  # Keep only letters and spaces
    words = text.split()
    words = [word for word in words if word not in stopwords.words('english')]
    return ' '.join(words)

X, y = X[:5000], y[:5000]

# Clean and preprocess text data
X_cleaned = [preprocess_text(doc.decode('utf-8', errors='ignore')) for doc in X]

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X_cleaned, y, test_size=0.2, random_state=42)

# Convert text to TF-IDF vectors
vectorizer = TfidfVectorizer(max_features=5000)
X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)

# Train a logistic regression model
model = LogisticRegression(max_iter=200)
model.fit(X_train_tfidf, y_train)

# Predict on test data
y_pred = model.predict(X_test_tfidf)

# Evaluate the model
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Script completed!")

#Additional Scripts

print("✅ Starting preprocessing...")

X_cleaned = [preprocess_text(doc.decode('utf-8', errors='ignore')) for doc in X]

print("✅ Preprocessing done. Splitting data...")

X_train, X_test, y_train, y_test = train_test_split(X_cleaned, y, test_size=0.2, random_state=42)

print("✅ Vectorizing text...")

vectorizer = TfidfVectorizer(max_features=5000)
X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)

print("✅ Training model...")

model = LogisticRegression(max_iter=200)
model.fit(X_train_tfidf, y_train)

print("✅ Making predictions...")

y_pred = model.predict(X_test_tfidf)

print("✅ Evaluation results:")

print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
